goc2p
=====

Go Concurrency Programming Project.

A example project for book 'Go Programming & Concurrency in Practice' (《Go并发编程实战》).
